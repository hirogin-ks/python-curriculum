BASE_URL = "https://books.toscrape.com/"
OUTPUT_DIR = "output"
